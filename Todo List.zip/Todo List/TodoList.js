// let submit =  document.querySelector(".submit")
// const newTask = document.querySelector(".lineByLine")


//  submit.addEventListener("click", () =>{
//     const input = document.querySelector("#input").value.trim();
//     document.querySelector("#input").value = ""
//      if (input !== "") {
//          let newElementCreate = document.createElement("div");
//          newElementCreate.innerHTML = `<div class="newCreateLine">
//          <input id="checkbox" type="checkbox">
//          <p>${input}</p>
//          <i id="delete"  class="fa-solid fa-circle-xmark fa-lg" style="color: #DC5780;"></i>
//          </div>`;         
//          newElementCreate.querySelector("#delete").addEventListener("click", () =>{
//              deleteElement(newElementCreate)
//             });
//             newTask.appendChild(newElementCreate)
//             document.querySelector(".selectedDelete").addEventListener("click", () =>{
//                 deleteButton(newElementCreate)
//             });

// }

// })

// let deleteElement = (ind)=>{
//          ind.remove()
// };

//  let deleteButton = (div) => {
//     let checkbox = div.querySelector("#checkbox");
//     if (checkbox.checked) {
//         deleteElement(div);
//     }
// };




let submit = document.querySelector(".submit");
const newTask = document.querySelector(".lineByLine");

submit.addEventListener("click", () => {
    const input = document.querySelector("#input").value.trim();
    document.querySelector("#input").value = "";
    if (input !== "") {
        let newElementCreate = document.createElement("div");
        newElementCreate.innerHTML = `<div class="newCreateLine">
            <input id="checkbox" type="checkbox">
            <p>${input}</p>
            <i id="delete" class="fa-solid fa-circle-xmark fa-lg" style="color: #DC5780;"></i>
        </div>`;
        let deleteButton = newElementCreate.querySelector("#delete");
        deleteButton.addEventListener("click", () => {
            deleteElement(newElementCreate);
        });
        newTask.appendChild(newElementCreate);
        let checkbox = newElementCreate.querySelector("#checkbox");
        checkbox.addEventListener("click", () => {
            deleteButton(newElementCreate);
        });
    }
});

let deleteElement = (element) => {
    element.remove();
};

let deleteButton = (div) => {
    let checkbox = div.querySelector("#checkbox");
    if (checkbox.checked) {
        deleteElement(div);
    }
};

