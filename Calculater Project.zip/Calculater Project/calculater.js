
let appendToDisplay = (value) => {
    let valueInput = document.getElementById('display');
    valueInput.value += value  
    
    
 
 }
 
 let resetDisplay = () => {
     document.getElementById('display').value = '';
 }
 
 let calculate = () => {
     let equalValue = document.getElementById('display').value
     if (equalValue === '') {
         alert('Input Filed Is Empty')
     }else{
         try {
             document.getElementById('display').value = eval(equalValue)
         } catch (error) {
             document.getElementById('display').value = ''
             alert(`Wrong Input : ${equalValue}`)
     }
 }
 
 }
 
 let deleteLastChar = ()=>{
     let valeSlice= document.getElementById('display').value 
     document.getElementById('display').value  = valeSlice.toString().slice(0,-1)
 }
 
 let calc = document.getElementById('calc')
 let switchButton = document.getElementById('switch')
 
 let isColor = true; 
 switchButton.addEventListener('click', ()=>{
     
     if (isColor) {
         document.body.style.backgroundColor ='white';
         calc.style.color='black'
     } else {
         
         document.body.style.backgroundColor = '#3B4664'
         calc.style.color='white'
      
     }
    //  isColor =! isColor
 })