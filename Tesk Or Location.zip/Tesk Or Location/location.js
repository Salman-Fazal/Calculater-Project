document.addEventListener("DOMContentLoaded", function() {
    const checkInBtn = document.getElementById("checkInBtn");
    const previousLocations = document.getElementById("previousLocations");
    const currentLatitude = document.getElementById("current-latitude");
    const currentLongitude = document.getElementById("current-longitude");
    const currentLocation = document.getElementById("current-location");

    // Function to add a new previous location entry
    function addPreviousLocation(location) {
        const newLocationDiv = document.createElement("div");
        newLocationDiv.classList.add("location-entry");
        newLocationDiv.innerHTML = `
            <p class="location-icon">📍</p>
            <p class="Address">${location}</p>
        `;
        previousLocations.appendChild(newLocationDiv);
    }

    // Function to get the current location
    function getCurrentLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                const latitude = position.coords.latitude;
                const longitude = position.coords.longitude;
                currentLatitude.textContent = `Latitude: ${latitude.toFixed(4)}`;
                currentLongitude.textContent = `Longitude: ${longitude.toFixed(4)}`;
                fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=en`)
                    .then(response => response.json())
                    .then(data => {
                        const city = data.locality ? data.locality : "Unknown Location";
                        currentLocation.textContent = city;
                        addPreviousLocation(city);
                    })
                    .catch(error => {
                        console.error('Error fetching location:', error);
                        currentLocation.textContent = "Unknown Location";
                        addPreviousLocation("Unknown Location");
                    });
            }, function(error) {
                console.error('Error getting current position:', error);
                currentLocation.textContent = "Unknown Location";
                addPreviousLocation("Unknown Location");
            });
        } else {
            console.error('Geolocation is not supported by this browser.');
            currentLocation.textContent = "Geolocation not supported";
            addPreviousLocation("Geolocation not supported");
        }
    }

    // Event listener for check-in button
    checkInBtn.addEventListener("click", function() {
        getCurrentLocation();
    });
});
