function displayTask(checkbox) {
  var taskDiv = checkbox.parentElement;
 

  if (checkbox.checked) {
            document.getElementById("completeTasks").appendChild(taskDiv);
  } else {
            document.getElementById("incompleteTasks").appendChild(taskDiv);
  }
} 


document.getElementById('myForm').addEventListener('submit', function(event) {
  event.preventDefault(); 

  
  var summary = document.getElementById('task').value;
  var description = document.getElementById('Description').value;
  var dueDate = document.getElementById('time').value;


  var taskDiv = document.createElement('div');
  taskDiv.className = 'row';
  taskDiv.innerHTML = `
      <input type="checkbox" class="checkBtn" onchange="moveTask(this)">
      <p>${summary}</p>
      <span>${description} ⏰ ${dueDate}</span>
  `;


  document.getElementById('incompleteTasks').appendChild(taskDiv);


  document.getElementById('task').value = '';
  document.getElementById('Description').value = '';
  document.getElementById('time').value = '';
  
});

function moveTask(checkbox) {
  var taskDiv = checkbox.parentElement;
  var incompleteDiv = document.getElementById('incompleteTasks');
  var completeDiv = document.getElementById('completeTasks');


  if (checkbox.checked) {
      completeDiv.appendChild(taskDiv);
  } else {
      incompleteDiv.appendChild(taskDiv);
  }
 

}


 // Function to handle task submission and reminder

document.querySelector('.resume').addEventListener('click', handleTask);
document.querySelector('.skip').addEventListener('click', handleSkip);
document.querySelector('.skip p').addEventListener('click', remindLater); 
     
function handleTask() {
  console.log("Submitting resume to DigitalTalk...");
}

// Function to remind later
function remindLater() {
  console.log("Reminding later...");
  alert("Don't forget to submit your resume later!");
}
remindLater();


function handleSkip() {
  console.log("Task skipped");
  remindLater();
}
handleSkip();









