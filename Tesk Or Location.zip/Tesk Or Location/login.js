document.addEventListener("DOMContentLoaded", function() {
  const passwordField = document.getElementById("password");
  const togglePassword = document.getElementById("togglePassword");

  togglePassword.addEventListener("click", function() {
      let type;
      if (passwordField.type === "password") {
          type = "text";
          togglePassword.innerHTML= "Hide";
      } else {
          type = "password";
          togglePassword.innerHTML= "Show";
      }
      passwordField.type = type;
      // Change the icon based on password visibility
      this.classList.toggle("fa-eye"); // Show open eye icon when revealed
  });
});

function login() {
  var email = document.getElementById("email").value;
  var password = document.getElementById("password").value;

  if(email == "Salmanmalikwork@gmail.com" && password == "Ayan.7786"){
      window.location.href = "task.html";
  } else {
      console.log("login failed");
      // You can display an error message here
  }
}

